% Demo for Structured Edge Detector (please see readme.txt first).

%% set opts for training (see edgesTrain.m)
opts=edgesTrain();                % default options (good settings)
opts.modelDir='models/';          % model will be in models/forest
opts.modelFnm='modelBsds';        % model name
opts.nPos=5e5; opts.nNeg=5e5;     % decrease to speedup training
opts.useParfor=0;                 % parallelize if sufficient memory

%% train edge detector (~20m/8Gb per tree, proportional to nPos/nNeg)
tic, model=edgesTrain(opts); toc; % will load model if already trained

%% set detection parameters (can set after training)
model.opts.multiscale=0;          % for top accuracy set multiscale=1
model.opts.sharpen=2;             % for top speed set sharpen=0
model.opts.nTreesEval=4;          % for top speed set nTreesEval=1
model.opts.nThreads=4;            % max number threads for evaluation
model.opts.nms=0;                 % set to true to enable nms

%% evaluate edge detector on BSDS500 (see edgesEval.m)
if(0), edgesEval( model, 'show',1, 'name','' ); end

%% detect edge and visualize results
I = imread('/home/leo/docker_ws/datasets/tinyTimeMachine/6z/6zHPQqtzrPsgvlgACNXC1g/_201407/6zHPQqtzrPsgvlgACNXC1g__201407_35.652096_139.712896_060_012.jpg');
tic, E=edgesDetect(I,model); toc
I2 = imread('/home/leo/docker_ws/datasets/tinyTimeMachine/6z/6zHPQqtzrPsgvlgACNXC1g/_201407/6zHPQqtzrPsgvlgACNXC1g__201407_35.652096_139.712896_090_012.jpg');
tic, E1=edgesDetect(I2,model); toc
%figure(1); im(I); figure(2); im(1-E);

Img_edges = im(1-E);
figure(1); 
subplot(1,2,1), im(1-E);
subplot(1,2,2), im(1-E1);
imwrite(E,'6z.jpg')
